def main(world, ghosts): 
  return (42, step)
def step(state, world):
  return (state+1, 2)
