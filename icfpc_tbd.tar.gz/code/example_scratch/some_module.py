import logging
log = logging.getLogger(__name__)

def f():
    log.info('f() called')
    return 4 # certified random number
